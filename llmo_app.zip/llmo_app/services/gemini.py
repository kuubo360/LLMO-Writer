# services/gemini.py（置き換え or 追記）

import os, re, json
import google.generativeai as genai

MODEL = "gemini-2.0-flash"

def _configure():
    key = os.environ.get("GEMINI_API_KEY")
    if not key:
        raise RuntimeError("GEMINI_API_KEY is not set")
    genai.configure(api_key=key)

def call_gemini(system: str, user: str, generation_config: dict | None = None) -> str:
    _configure()
    m = genai.GenerativeModel(MODEL)
    resp = m.generate_content([system, user], generation_config=generation_config or {})
    return (resp.text or "").strip()

def call_gemini_json(system: str, user: str) -> str:
    """JSONのみ返すようモデルに明示（かなり効きます）"""
    return call_gemini(
        system,
        user,
        generation_config={
            "response_mime_type": "application/json",
            # 本文が長いので上限も広めに
            "max_output_tokens": 4096,
            "temperature": 0.7,
            "top_p": 0.9,
        },
    )

def extract_json_safe(text: str) -> dict:
    s = re.sub(r"^```[a-zA-Z]*\s*", "", text).strip()
    s = re.sub(r"\s*```$", "", s)
    s = s.replace('"内容"', '"content"')
    s = re.sub(r",(\s*[}\]])", r"\1", s)
    m = re.search(r"\{.*\}\s*$", s, re.S)
    if not m:
        raise ValueError("JSON not found in output:\n" + text)
    js = m.group(0)
    try:
        return json.loads(js)
    except Exception:
        return json.loads(js.replace("：", ":"))
