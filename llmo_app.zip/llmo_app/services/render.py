# services/render.py
import datetime, json

def build_jsonld(article: dict) -> str:
    faq = article["sections"].get("faq")
    faq_entities = []
    if isinstance(faq, list) and faq and isinstance(faq[0], dict):
        for qa in faq:
            faq_entities.append({
                "@type": "Question",
                "name": qa.get("question",""),
                "acceptedAnswer": {"@type":"Answer","text": qa.get("answer","")}
            })
    data = {
        "@context":"https://schema.org",
        "@type":"Article",
        "headline": article["query"],
        "datePublished": datetime.datetime.now().strftime("%Y-%m-%d"),
        "dateModified": datetime.datetime.now().strftime("%Y-%m-%d"),
        "author":{"@type":"Organization","name":"Local AI Writer"},
        "mainEntity": []
    }
    if faq_entities:
        data["mainEntity"].append({"@type":"FAQPage","mainEntity": faq_entities})
    return json.dumps(data, ensure_ascii=False, indent=2)

def safe_p(x):
    if isinstance(x, list):
        return "<br>".join([str(i) for i in x])
    return str(x)

def render_marked_up_article(sections: dict) -> str:
    html = []
    def add(title, key):
        if sections.get(key):
            html.append(f"<h2>{title}</h2><p>{safe_p(sections[key])}</p>")
    add("イントロ","intro")
    add("概要","overview")
    if sections.get("key_points"):
        items = sections["key_points"] if isinstance(sections["key_points"], list) else [sections["key_points"]]
        html.append("<h2>ポイント</h2><ul>" + "".join(f"<li>{i}</li>" for i in items) + "</ul>")
    add("方法","methodology")
    if sections.get("advantages"):
        adv = sections["advantages"]
        if isinstance(adv, list):
            html.append("<h2>メリット</h2><ul>" + "".join(f"<li>{i}</li>" for i in adv) + "</ul>")
        else: add("メリット","advantages")
    if sections.get("disadvantages"):
        dis = sections["disadvantages"]
        if isinstance(dis, list):
            html.append("<h2>デメリット</h2><ul>" + "".join(f"<li>{i}</li>" for i in dis) + "</ul>")
        else: add("デメリット","disadvantages")
    if sections.get("use_cases"):
        uc = sections["use_cases"]
        if isinstance(uc, list):
            html.append("<h2>ユースケース</h2><ul>" + "".join(f"<li>{i}</li>" for i in uc) + "</ul>")
        else: add("ユースケース","use_cases")
    if sections.get("original_data"):
        html.append(f"<h2>独自のデータ</h2><p>{safe_p(sections['original_data'])}</p>")
    if sections.get("faq"):
        faq = sections["faq"]
        if isinstance(faq, list) and faq and isinstance(faq[0], dict):
            html.append("<h2>FAQ</h2>" + "".join(f"<h3>{qa.get('question','')}</h3><p>{qa.get('answer','')}</p>" for qa in faq))
        else:
            html.append(f"<h2>FAQ</h2><p>{safe_p(faq)}</p>")
    add("今後の見通し","future_outlook")
    add("まとめ","conclusion")
    if sections.get("references"):
        refs = sections["references"] if isinstance(sections["references"], list) else [sections["references"]]
        html.append("<h2>参考資料</h2><ul>" + "".join(f"<li><a href='{r}' target='_blank' rel='nofollow noopener'>{r}</a></li>" for r in refs) + "</ul>")
    return "\n".join(html)
