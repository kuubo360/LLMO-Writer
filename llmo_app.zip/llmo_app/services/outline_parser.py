# services/outline_parser.py
import requests, bs4, re

def fetch_html(url: str, timeout: int = 20) -> str:
    r = requests.get(url, timeout=timeout, headers={"User-Agent":"Mozilla/5.0"})
    r.raise_for_status()
    return r.text

def extract_outline_from_html(html: str):
    soup = bs4.BeautifulSoup(html, "lxml")
    # Try to extract headings h1-h3 and common nav items
    headings = []
    for tag in soup.find_all(["h1","h2","h3"]):
        txt = " ".join(tag.get_text(" ").split())
        if txt and len(txt) <= 120:
            headings.append((tag.name, txt))

    # Deduplicate while preserving order
    seen = set()
    uniq = []
    for level, txt in headings:
        key = (level, txt.lower())
        if key in seen: continue
        seen.add(key)
        uniq.append((level, txt))

    # Build simple outline
    topic_order = []
    topics = {}
    for level, txt in uniq:
        key = re.sub(r"\W+", "_", txt.lower()).strip("_")
        if not key: continue
        if key in topics: continue
        topics[key] = {"title": txt}
        topic_order.append(key)

    # Heuristic: ensure intro/conclusion present
    def inject(key, title, pos=None):
        if key not in topics:
            topics[key] = {"title": title}
            if pos is None: topic_order.append(key)
            else: topic_order.insert(pos, key)

    if topic_order and topic_order[0] not in ("intro","introduction"):
        inject("intro","イントロダクション", pos=0)
    if "faq" not in topics:
        inject("faq","FAQ")
    if "conclusion" not in topics and "まとめ" not in [t.get("title","") for t in topics.values()]:
        inject("conclusion","まとめ")

    return {"topic_order": topic_order, "topics": topics}
