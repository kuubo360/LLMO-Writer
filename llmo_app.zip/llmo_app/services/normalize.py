# services/normalize.py
import re

def parse_faq_text(text: str):
    qa = []
    import re as _re
    blocks = _re.split(r'(?=Q[:：])', text.strip())
    for b in blocks:
        b = b.strip()
        if not b: continue
        m_q = _re.search(r'^Q[:：]\s*(.+)', b)
        m_a = _re.search(r'A[:：]\s*(.+)', b, _re.S)
        if m_q and m_a:
            qa.append({"question": m_q.group(1).strip(), "answer": m_a.group(1).strip()})
        else:
            lines = [ln.strip() for ln in b.splitlines() if ln.strip()]
            if not lines: continue
            q = lines[0][:80]; a = "\n".join(lines[1:]) if len(lines)>1 else ""
            qa.append({"question": q, "answer": a})
    if not qa:
        lines = [ln.strip("・-• ").strip() for ln in text.splitlines() if ln.strip()]
        for i, ln in enumerate(lines, 1):
            qa.append({"question": f"質問{i}", "answer": ln})
    return qa

def normalize_sections(sections: dict) -> dict:
    def collapse(v):
        if isinstance(v, dict):
            title = v.get("title") or v.get("題名") or ""
            content = v.get("content") or v.get("内容") or ""
            if content and title: return f"{title}\n{content}"
            return content or title
        return v

    alias = {
        "intro": ["intro","introduction","lead"],
        "overview": ["overview","summary","abstract"],
        "key_points": ["key_points","keypoints","highlights","bullets"],
        "methodology": ["methodology","approach","process","methods"],
        "advantages": ["advantages","pros","benefits"],
        "disadvantages": ["disadvantages","cons","limitations"],
        "use_cases": ["use_cases","cases","examples"],
        "faq": ["faq","qna","questions","faqs"],
        "future_outlook": ["future_outlook","outlook","roadmap"],
        "conclusion": ["conclusion","closing","summary_end"],
        "references": ["references","citations","sources"],
        "original_data": ["original_data","独自のデータ","custom_data","own_data"]
    }
    reverse = {n:k for k, names in alias.items() for n in names}
    norm = {}
    for k,v in sections.items():
        std = reverse.get(k,k); norm[std] = collapse(v)

    if "key_points" in norm and isinstance(norm["key_points"], str):
        items = [s.strip("・-• ").strip() for s in norm["key_points"].splitlines() if s.strip()]
        norm["key_points"] = [i for i in items if i]

    if "faq" in norm:
        if isinstance(norm["faq"], str):
            norm["faq"] = parse_faq_text(norm["faq"])
        elif isinstance(norm["faq"], list) and norm["faq"] and isinstance(norm["faq"][0], str):
            norm["faq"] = parse_faq_text("\n".join(norm["faq"]))

    if "references" in norm:
        refs = norm["references"]; urls = []
        if isinstance(refs, str):
            urls = re.findall(r"https?://[^\s)\]]+", refs)
        elif isinstance(refs, list):
            for r in refs:
                if isinstance(r, str):
                    urls += re.findall(r"https?://[^\s)\]]+", r)
        norm["references"] = list(dict.fromkeys(urls))
    return norm
