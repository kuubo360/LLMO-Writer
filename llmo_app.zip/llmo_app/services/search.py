# services/search.py
import os, requests
LANG, TOPK = "ja", 3

def serper_search(query: str):
    key = os.environ.get("SERPER_API_KEY")
    if not key:
        raise RuntimeError("SERPER_API_KEY is not set")
    r = requests.post(
        "https://google.serper.dev/search",
        headers={"X-API-KEY": key, "Content-Type":"application/json"},
        json={"q": query, "hl": LANG, "num": TOPK}, timeout=30
    )
    r.raise_for_status()
    return r.json()
