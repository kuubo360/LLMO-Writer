# blueprints/article.py
import datetime, pathlib, json, re
from flask import Blueprint, request, jsonify, abort

from services.gemini import call_gemini_json, call_gemini, extract_json_safe
from services.normalize import normalize_sections
from services.render import render_marked_up_article, build_jsonld
from blueprints.outline import STATE

bp = Blueprint("article", __name__)

# --------------------
# LLM TXT 保存ユーティリティ
# --------------------
def save_llm_txt(query: str, sections: dict) -> str:
    base = pathlib.Path("static/llm")
    base.mkdir(parents=True, exist_ok=True)
    fname = base / f"llm_{query.replace(' ', '_')}.txt"
    lines = [
        f"Article Title: {query}",
        f"Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "Sections:"
    ]
    for key in sections.keys():
        lines.append(f"- {key}")
    refs = sections.get("references")
    if refs:
        lines.append("\nReferences:")
        if isinstance(refs, list):
            lines.extend([f"- {r}" for r in refs])
        else:
            lines.append(f"- {refs}")
    fname.write_text("\n".join(lines), encoding="utf-8")
    return str(fname)

# --------------------
# 記事生成（アウトライン駆動 / 1回で全体を生成）
# --------------------
@bp.route("/generate", methods=["POST"])
def generate():
    if not STATE.get("current_outline"):
        abort(400, "outline not committed")
    if not STATE.get("serp"):
        abort(400, "SERP missing")

    outline = STATE["current_outline"]
    topic_order = outline.get("topic_order") or []
    topics = outline.get("topics") or {}

    # タイトルからFAQ系かどうかを判定
    def is_faq_like(title: str) -> bool:
        t = (title or "").lower()
        return ("faq" in t) or ("q&a" in t) or ("よくある質問" in t)

    # モデルへの指示（固定キーは使わず、アウトラインをそのまま踏襲）
    system = (
        "あなたはSEO記事の編集長です。"
        "与えられた『アウトライン(JSON)』『検索結果(JSON)』『独自データ(テキスト)』を参考に、"
        "アウトラインのキー/順序/タイトルをそのまま踏襲して本文を生成してください。"
        "出力は JSON のみ。次の形式に厳密に従ってください：\n"
        "{\n"
        '  "sections": {\n'
        '    "<outline_key>": {\n'
        '      "title": "<outline_title をそのままコピー>",\n'
        '      "body": "1〜3段落の本文（FAQでない場合）"\n'
        '      // もしタイトルに「FAQ」や「Q&A」を含む場合は body ではなく\n'
        '      // "items": [{"question":"…","answer":"…"}, ...] を返す（各2〜4問）\n'
        "    }, ...\n"
        "  },\n"
        '  "references": ["URL", ...] // 見つかれば\n'
        "}\n"
        "禁止事項：\n"
        " - アウトラインに無いキーを増やさない・キー名を変えない\n"
        " - 見出し語を並べるだけにしない（各本文は120〜200日本語文字×1〜3段落）\n"
        " - コードフェンスや説明文を出さない（JSON以外を出力しない）\n"
        "注意：独自データがあれば自然に本文へ織り込むこと。"
    )

    # 形だけ示す few-shot（中身は無視）
    fewshot = {
        "sections": {
            "intro_like_key": {"title": "イントロダクション", "body": "…本文…"},
            "faq_block": {
                "title": "FAQ",
                "items": [
                    {"question": "…?", "answer": "…"},
                    {"question": "…?", "answer": "…"}
                ]
            }
        },
        "references": ["https://example.com/a","https://example.com/b"]
    }

    # 生成対象のキーとタイトル（順序保証用）
    ordered_keys = [{"key": k, "title": topics.get(k, {}).get("title", "")} for k in topic_order]

    user = f"""
# アウトライン（人が確定した構造）
{json.dumps(outline, ensure_ascii=False, indent=2)}

# 検索結果(上位3件)
{json.dumps((STATE['serp'].get('organic') or [])[:3], ensure_ascii=False, indent=2)}

# 独自データ
{STATE.get('custom_data') or '（なし）'}

# 参考フォーマット（形だけ参照、中身は無視）
{json.dumps(fewshot, ensure_ascii=False, indent=2)}

# 重要：生成対象のキーとタイトル（この順序どおり、キー名を変えないこと）
{json.dumps(ordered_keys, ensure_ascii=False)}
"""

    # JSON専用モードで生成
    raw = call_gemini_json(system, user)
    try:
        data = extract_json_safe(raw)
    except Exception:
        # フォールバック：最初のキーに本文としてそのまま突っ込む
        first_key = topic_order[0] if topic_order else "intro"
        data = {"sections": {first_key: {"title": topics.get(first_key, {}).get("title", first_key),
                                         "body": raw}}}

    sections_raw = data.get("sections") or {}

    # 足りないキーを空本文で補完 / 過剰キーは削除（アウトラインを唯一の基準に）
    for k in topic_order:
        if k not in sections_raw:
            sections_raw[k] = {"title": topics.get(k, {}).get("title", ""), "body": ""}
    sections_raw = {k: sections_raw[k] for k in topic_order}

    # 本文の薄さや見出し語の繰り返しが多い場合は軽く再要請（任意）
    def total_body_len(secs: dict) -> int:
        s = []
        for v in secs.values():
            if isinstance(v, dict) and isinstance(v.get("body"), str):
                s.append(v["body"])
        return len("\n".join(s))

    def overlap_ratio(secs: dict) -> float:
        bodies = []
        titles = []
        for k in topic_order:
            v = secs.get(k) or {}
            t = topics.get(k, {}).get("title", "")
            titles.append(t.lower())
            bodies.append((v.get("body") or "").lower())
        joined = " ".join(bodies)
        if not joined:
            return 1.0
        hits = sum(1 for t in titles if t and t in joined)
        return hits / max(1, len(titles))

    need_retry = total_body_len(sections_raw) < 800 or overlap_ratio(sections_raw) > 0.6
    if need_retry:
        reinforce = (
            "前回の出力は本文量/重複が不十分でした。"
            "アウトラインの語を並べるのではなく、各セクションで具体例・数値・因果関係を1〜3段落で説明してください。"
            "同じ形式のJSONのみを返してください。"
        )
        raw2 = call_gemini_json(system, user + "\n\n" + reinforce)
        try:
            data2 = extract_json_safe(raw2)
            if data2.get("sections"):
                sections_raw = data2["sections"]
        except Exception:
            pass
        # 再度のキー補完/削除
        for k in topic_order:
            if k not in sections_raw:
                sections_raw[k] = {"title": topics.get(k, {}).get("title", ""), "body": ""}
        sections_raw = {k: sections_raw[k] for k in topic_order}

    # 既存のレンダラが扱える形に変換：
    #  - FAQセクションは list[{question,answer}]
    #  - それ以外は本文文字列
    cooked = {}
    for k in topic_order:
        sec = sections_raw.get(k) or {}
        title = sec.get("title") or topics.get(k, {}).get("title", "") or k
        # FAQ判定
        if ("items" in sec) or ("faq" in title.lower()) or ("q&a" in title.lower()) or ("よくある質問" in title):
            items = sec.get("items") or []
            faq = []
            for it in items:
                q = (it.get("question") or it.get("q") or "").strip()
                a = (it.get("answer") or it.get("a") or "").strip()
                if q or a:
                    faq.append({"question": q, "answer": a})
            cooked[k] = faq
        else:
            cooked[k] = (sec.get("body") or "").strip()

    # references はそのまま
    if "references" in data and data["references"]:
        cooked["references"] = data["references"]

    # 正規化 → マークアップ/JSON-LD
    sections = normalize_sections(cooked)
    if STATE.get("custom_data") and not sections.get("original_data"):
        sections["original_data"] = STATE["custom_data"]

    article = {"query": STATE["query"], "sections": sections}
    markup = render_marked_up_article(sections)
    jsonld = build_jsonld(article)
    save_llm_txt(STATE["query"], sections)

    # キャッシュ
    STATE["article"] = article
    STATE["markup"] = markup
    STATE["jsonld"] = jsonld

    return jsonify({"sections": sections, "markup": markup, "jsonld": jsonld})

# --------------------
# セクション編集（人手で編集 → 同期反映）
# --------------------
@bp.route("/edit", methods=["POST"])
def edit():
    data = request.get_json(force=True)
    sec = data.get("section")
    new_text = data.get("new_text", "")
    if not STATE.get("article"):
        abort(400, "article missing")
    if sec not in STATE["article"]["sections"]:
        abort(400, "unknown section")

    STATE["article"]["sections"][sec] = new_text
    # 再整形
    sections = normalize_sections(STATE["article"]["sections"])
    STATE["article"]["sections"] = sections
    STATE["markup"] = render_marked_up_article(sections)
    STATE["jsonld"] = build_jsonld(STATE["article"])

    return jsonify({"new_text": new_text, "markup": STATE["markup"], "jsonld": STATE["jsonld"]})

# --------------------
# セクション再生成（必要箇所だけAIで書き直し）
# --------------------
@bp.route("/regenerate", methods=["POST"])
def regenerate():
    data = request.get_json(force=True)
    sec = data.get("section")
    current_text = data.get("current_text", "")
    if not STATE.get("article"):
        abort(400, "article missing")
    if sec not in STATE["article"]["sections"]:
        abort(400, "unknown section")

    # コンテキスト：全体のアウトライン・独自データ・テーマ
    outline = STATE.get("current_outline") or {}
    topics = outline.get("topics") or {}
    title = (topics.get(sec, {}) or {}).get("title", sec)

    # FAQならQ/A配列で、そうでなければ本文テキストで返すよう指示
    faq_like = ("faq" in title.lower()) or ("q&a" in title.lower()) or ("よくある質問" in title)

    if faq_like:
        system = (
            f"次のセクション（{title}）を改善してください。"
            "出力はJSONのみで、items: [{question, answer}] の配列として2〜4問返してください。"
            "独自データがあれば整合性を高めてください。"
        )
        user = f"""
# テーマ
{STATE['query']}

# 現在のQ&A
{json.dumps(STATE['article']['sections'].get(sec), ensure_ascii=False, indent=2)}

# 独自データ
{STATE.get('custom_data') or '（なし）'}
"""
        raw = call_gemini_json(system, user)
        try:
            data2 = extract_json_safe(raw)
            items = data2.get("items") or []
            faq = []
            for it in items:
                q = (it.get("question") or it.get("q") or "").strip()
                a = (it.get("answer") or it.get("a") or "").strip()
                if q or a:
                    faq.append({"question": q, "answer": a})
            new_text = faq
        except Exception:
            # 壊れていたら現状維持
            new_text = STATE["article"]["sections"].get(sec)
    else:
        system = (
            f"次のセクション（{title}）を改善してください。"
            "出力はプレーンテキストのみ。箇条書き・改行は可。"
            "アウトラインの見出し語を並べるのではなく、1〜3段落で具体例・数値・因果関係を説明してください。"
            "独自データがあれば自然に織り込んでください。"
        )
        user = f"""
# テーマ
{STATE['query']}

# 現在の本文
{current_text}

# 独自データ
{STATE.get('custom_data') or '（なし）'}
"""
        raw = call_gemini(system, user)
        new_text = (raw or "").strip()

    STATE["article"]["sections"][sec] = new_text
    sections = normalize_sections(STATE["article"]["sections"])
    STATE["article"]["sections"] = sections
    STATE["markup"] = render_marked_up_article(sections)
    STATE["jsonld"] = build_jsonld(STATE["article"])

    return jsonify({"new_text": STATE['article']['sections'][sec],
                    "markup": STATE["markup"], "jsonld": STATE["jsonld"]})
