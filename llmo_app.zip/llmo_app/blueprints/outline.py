# blueprints/outline.py
from flask import Blueprint, request, jsonify, abort
from services.search import serper_search
from services.outline_parser import fetch_html, extract_outline_from_html

bp = Blueprint("outline", __name__)

# Simple in-memory state
STATE = {
    "query": "",
    "custom_data": "",
    "serp": {},
    "candidates": [],  # list of outlines with source_url
    "current_outline": None,
}

@bp.route("/generate", methods=["POST"])
def generate():
    data = request.get_json(force=True)
    q = (data.get("query") or "").strip()
    cd = data.get("custom_data","")
    if not q: abort(400, "query required")

    serp = serper_search(q)
    org = (serp.get("organic") or [])[:3]

    candidates = []
    errors = []
    for item in org:
        url = item.get("link") or item.get("url")
        if not url: continue
        try:
            html = fetch_html(url)
            outline = extract_outline_from_html(html)
            outline["source_url"] = url
            candidates.append(outline)
        except Exception as e:
            errors.append({"url": url, "error": str(e)})

    if not candidates:
        abort(500, "Failed to build outlines from top results")

    STATE.update({"query": q, "custom_data": cd, "serp": serp, "candidates": candidates})
    return jsonify({"candidates": candidates, "errors": errors})

@bp.route("/commit", methods=["POST"])
def commit():
    data = request.get_json(force=True)
    q = (data.get("query") or "").strip()
    cd = data.get("custom_data","")
    outline = data.get("outline")
    if not outline: abort(400, "outline required")
    STATE.update({"query": q or STATE["query"], "custom_data": cd, "current_outline": outline})
    return jsonify({"ok": True, "outline": outline})
