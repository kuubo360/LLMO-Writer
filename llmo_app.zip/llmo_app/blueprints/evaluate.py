# blueprints/evaluate.py（置き換え）
import json
from flask import Blueprint, jsonify, abort
from services.gemini import call_gemini, extract_json_safe
from blueprints.outline import STATE

bp = Blueprint("evaluate", __name__)

@bp.route("", methods=["POST"])
def evaluate():
    if not STATE.get("article"):
        abort(400, "article missing")

    article_json = json.dumps(STATE["article"], ensure_ascii=False, indent=2)
    prompt = (
        "以下のSEO記事（JSON）を評価してください。JSONで返してください。"
        "キー: {"
        "\"comprehensiveness\": {\"score\":1-5, \"reason\":\"...\"}, "
        "\"readability\": {\"score\":1-5, \"reason\":\"...\"}, "
        "\"authority\": {\"score\":1-5, \"reason\":\"...\"}, "
        "\"seo_fitness\": {\"score\":1-5, \"reason\":\"...\"}, "
        "\"improvement_suggestions\": [\"...\", \"...\"], "
        "\"overall_comment\": \"...\"}"
        "。独自データ(original_data)の活用度合いも authority に反映してください。"
    )
    raw = call_gemini(prompt, article_json)
    try:
        data = extract_json_safe(raw)
    except Exception:
        # どうしてもJSONで来なければそのまま表示
        return jsonify({"report": raw})

    # 人間向けに整形
    def line(k):
        obj = data.get(k, {})
        if isinstance(obj, dict):
            sc = obj.get("score", "-")
            rs = obj.get("reason", "")
            return f"■ {k}：{sc}/5\n{rs}\n"
        return ""

    suggestions = ""
    if isinstance(data.get("improvement_suggestions"), list):
        suggestions = "\n".join([f"- {s}" for s in data["improvement_suggestions"]])

    report = (
        f"{line('comprehensiveness')}"
        f"{line('readability')}"
        f"{line('authority')}"
        f"{line('seo_fitness')}"
        f"■ 改善提案\n{suggestions}\n\n"
        f"■ 総評\n{data.get('overall_comment','')}"
    )
    return jsonify({"report": report})
