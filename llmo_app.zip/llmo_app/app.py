# app.py
import os
from flask import Flask, render_template
from blueprints.outline import bp as outline_bp
from blueprints.article import bp as article_bp
from blueprints.evaluate import bp as eval_bp

app = Flask(__name__)

# Register blueprints
app.register_blueprint(outline_bp, url_prefix="/outline")
app.register_blueprint(article_bp, url_prefix="/article")
app.register_blueprint(eval_bp, url_prefix="/evaluate")

@app.route("/")
def index():
    return render_template("index.html")

if __name__ == "__main__":
    # Dependencies:
    #   pip install flask requests google-generativeai beautifulsoup4 lxml
    # Env vars (Windows example):
    #   setx SERPER_API_KEY "xxxx"
    #   setx GEMINI_API_KEY "xxxx"
    # Reopen terminal then:
    #   python app.py
    app.run(debug=True)
